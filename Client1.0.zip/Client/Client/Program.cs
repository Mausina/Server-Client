﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;  
class Program
{
    static void Main()
    {
        Console.Write("Enter IP: ");
        string serverIp = Console.ReadLine();
        Console.Write("Enter Time(1=1min):");
        double pausa = Convert.ToDouble(Console.ReadLine());
        Thread.Sleep((int)pausa * 60 * 1000);
        SendShutdownCommand(serverIp); 
    }
    static void SendShutdownCommand(string serverIp)
    {
        try
        {
            using (TcpClient client = new TcpClient(serverIp, 12345))
            {
                using (NetworkStream stream = client.GetStream())
                {
                    string command = "shutdown";
                    byte[] data = Encoding.UTF8.GetBytes(command);
                    stream.Write(data, 0, data.Length);
                    Console.WriteLine("command sent");
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }
}

