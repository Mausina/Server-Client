﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

class Program
{
    [DllImport("kernel32.dll")]
    static extern IntPtr GetConsoleWindow();

    [DllImport("user32.dll")]
    static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    const int SW_HIDE = 0;
    [STAThread]
    static void Main()
    {
        IntPtr handle = GetConsoleWindow();
        ShowWindow(handle, SW_HIDE);
        StartServer();
    }
    static void StartServer()
    {
        TcpListener tcpListener = new TcpListener(IPAddress.Any, 12345);
        tcpListener.Start();

        Console.WriteLine("wait connection...");

        try
        {
            while (true)
            {
                TcpClient tcpClient = tcpListener.AcceptTcpClient();
                Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClientComm));
                clientThread.Start(tcpClient);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
        finally
        {
            tcpListener.Stop();
        }
    }

    static void HandleClientComm(object clientObj)
    {
        TcpClient tcpClient = (TcpClient)clientObj;

        using (NetworkStream networkStream = tcpClient.GetStream())
        {
            byte[] buffer = new byte[1024];
            int bytesRead = networkStream.Read(buffer, 0, buffer.Length);

            string command = Encoding.UTF8.GetString(buffer, 0, bytesRead);
            Console.WriteLine($"Command received: {command}");

            if (command.ToLower() == "shutdown")
            {
                ExecuteShutdownCommand();
            }
        }

        tcpClient.Close();
    }
    static void ExecuteShutdownCommand()
    {
        ProcessStartInfo psi = new ProcessStartInfo("C:\\Windows\\System32\\shutdown.exe", "/s /t 10")
        {
            CreateNoWindow = true,
            UseShellExecute = false
        };
        Process.Start(psi);
    }
}
